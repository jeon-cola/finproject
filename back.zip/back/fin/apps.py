from django.apps import AppConfig


class FinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fin'
